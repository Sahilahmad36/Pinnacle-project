import React from "react";
import { BrowserRouter, Routes, Route } from "react-router-dom";
import Home from "./components/Home";  
import Navbar from "./components/Navbar"; 

import Footer from "./components/Footer";
import About from "./pages/About";
import Ameniti from "./pages/Ameniti";
import Floorplan from "./pages/Floorplan";
import LifeStyle from "./pages/LifeStyle";
import Contact from "./pages/Contact";

const App = () => {
  return (
    <BrowserRouter> 
      <Navbar /> 
      
      <Routes>
        <Route path="/" element={<Home />} />  
        <Route path="/about-us" element={<About />} />  
        <Route path="/amenities" element={<Ameniti />} /> 
        <Route path="/floor-plan" element={<Floorplan />} /> 
        <Route path="/life-style" element={<LifeStyle />} /> 
        <Route path="/contact" element={<Contact />} /> 
      </Routes>
    
      <Footer />
    </BrowserRouter>
  );
};

export default App;
