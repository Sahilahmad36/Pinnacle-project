import React, { useEffect } from "react";
import Marquee from "react-fast-marquee";



const Clients = () => {


  return (
    <div  className="text-[#7A6960] mb-10">
    
     
      <p className="text-black text-center mt-7 mb-10 text-lg font-bold lg:px-0 px-6">
      Trusted by over 150+ major companies
      </p>

      <Marquee pauseOnHover="true" className="flex items-center">
        <img className="w-28 mr-20" src="https://homelengoreact.vercel.app/images/partner/partner1.svg" alt="img1" />
        <img className="w-28 mr-20" src="https://homelengoreact.vercel.app/images/partner/partner3.svg" alt="img2" />
        <img className="w-28 mr-20" src="https://homelengoreact.vercel.app/images/partner/partner1.svg" alt="img3" />
        <img className="w-28 mr-20" src="https://homelengoreact.vercel.app/images/partner/partner3.svg" alt="img4" />
        <img className="w-28 mr-20" src="https://homelengoreact.vercel.app/images/partner/partner1.svg" alt="img5" />
        <img className="w-28 mr-20" src="https://homelengoreact.vercel.app/images/partner/partner3.svg" alt="img6" />
        <img className="w-28 mr-20" src="https://homelengoreact.vercel.app/images/partner/partner1.svg" alt="img7" />
        <img className="w-28 mr-20" src="https://homelengoreact.vercel.app/images/partner/partner3.svg" alt="img8" />
        <img className="w-28 mr-20" src="https://homelengoreact.vercel.app/images/partner/partner1.svg" alt="img9" />
      </Marquee>
    </div>
  ); 
};

export default Clients;
