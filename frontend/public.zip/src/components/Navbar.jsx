import React, { useState } from "react";
import {Link} from "react-router-dom"
import { AiOutlineMenuUnfold } from "react-icons/ai";
import { AiOutlineClose } from "react-icons/ai";

const Navbar = () => {
  const [menu, setMenu] = useState(false);

  const handleChange = () => {
    setMenu(!menu);
  };

  const closeMenu = () => {
    setMenu(false);
  };
  const scrollToTop = () => {
    window.scrollTo(0, 0);
  };

  return (
    <div className="fixed top-0 left-0 w-full z-50 bg-black bg-opacity-60 shadow-[0_3px_10px_rgb(0,0,0,0.2)]">
      <div>
        <div className="flex flex-row justify-between p-5 px-5 text-white"
        onClick={scrollToTop}
        >
          <nav className="hidden md:flex flex-row items-center justify-center text-lg font-medium gap-8 w-full">
            <Link
              to="/"
              spy={true}
              smooth={true}
              duration={500}
              className="group relative inline-block cursor-pointer hover:text-brightColor"
            >
              Home
              <span className="absolute inset-x-0 bottom-0 h-0.5 bg-[#e4b077] transform scale-x-0 origin-left transition-transform group-hover:scale-x-100"></span>
            </Link>

            <Link
              to="/about-us"
              spy={true}
              smooth={true}
              duration={500}
              className="group relative inline-block cursor-pointer hover:text-brightColor"
            >
              About Us
              <span className="absolute inset-x-0 bottom-0 h-0.5 bg-[#e4b077] transform scale-x-0 origin-left transition-transform group-hover:scale-x-100"></span>
            </Link>

            <Link
              to="/amenities"
              spy={true}
              smooth={true}
              duration={500}
              className="group relative inline-block cursor-pointer hover:text-brightColor"
            >
              Amenities
              <span className="absolute inset-x-0 bottom-0 h-0.5 bg-[#e4b077] transform scale-x-0 origin-left transition-transform group-hover:scale-x-100"></span>
            </Link>

            <Link
              to="/floor-plan"
              spy={true}
              smooth={true}
              duration={500}
              className="group relative inline-block cursor-pointer hover:text-brightColor"
            >
              Floor Plans
              <span className="absolute inset-x-0 bottom-0 h-0.5 bg-[#e4b077] transform scale-x-0 origin-left transition-transform group-hover:scale-x-100"></span>
            </Link>
            <Link
              to="/life-style"
              spy={true}
              smooth={true}
              duration={500}
              className="group relative inline-block cursor-pointer hover:text-brightColor"
            >
              Lifestyle
              <span className="absolute inset-x-0 bottom-0 h-0.5 bg-[#e4b077] transform scale-x-0 origin-left transition-transform group-hover:scale-x-100"></span>
            </Link>
            <Link
              to="/contact"
              spy={true}
              smooth={true}
              duration={500}
              className="group relative inline-block cursor-pointer hover:text-brightColor"
            >
              Contact Us
              <span className="absolute inset-x-0 bottom-0 h-0.5 bg-[#e4b077] transform scale-x-0 origin-left transition-transform group-hover:scale-x-100"></span>
            </Link>
            <Link
              to="/"
              spy={true}
              smooth={true}
              duration={500}
              className="group relative inline-block cursor-pointer hover:text-brightColor"
            >
              Forms & Rules
              <span className="absolute inset-x-0 bottom-0 h-0.5 bg-[#e4b077] transform scale-x-0 origin-left transition-transform group-hover:scale-x-100"></span>
            </Link>
            <Link
              to="/"
              spy={true}
              smooth={true}
              duration={500}
              className="group relative inline-block cursor-pointer hover:text-brightColor"
            >
              Residents Only
              <span className="absolute inset-x-0 bottom-0 h-0.5 bg-[#e4b077] transform scale-x-0 origin-left transition-transform group-hover:scale-x-100"></span>
            </Link>
            <Link
              to="/"
              spy={true}
              smooth={true}
              duration={500}
              className="group relative inline-block cursor-pointer hover:text-brightColor"
            >
              Notices
              <span className="absolute inset-x-0 bottom-0 h-0.5 bg-[#e4b077] transform scale-x-0 origin-left transition-transform group-hover:scale-x-100"></span>
            </Link>
            <Link
              to="/"
              spy={true}
              smooth={true}
              duration={500}
              className="group relative inline-block cursor-pointer hover:text-brightColor"
            >
              Insurance
              <span className="absolute inset-x-0 bottom-0 h-0.5 bg-[#e4b077] transform scale-x-0 origin-left transition-transform group-hover:scale-x-100"></span>
            </Link>
          </nav>

          <div className="md:hidden flex items-center">
            {menu ? (
              <AiOutlineClose
                size={25}
                onClick={handleChange}
                className="text-white"
              />
            ) : (
              <AiOutlineMenuUnfold
                size={25}
                onClick={handleChange}
                className="text-white"
              />
            )}
          </div>
        </div>

        <div
        onClick={scrollToTop}
          className={`${
            menu ? "translate-x-0" : "-translate-x-full"
          } flex flex-col absolute bg-black bg-opacity-70 text-white left-0 top-16 font-semibold text-lg text-center pt-8 pb-4 gap-4 w-full h-fit transition-transform duration-300 ease-in-out z-40`}
        >
          <Link
            to="/"
            spy={true}
            smooth={true}
            duration={500}
            className="hover:text-brightColor transition-all cursor-pointer"
            onClick={closeMenu}
          >
            Home
          </Link>
          <Link
            to="/about-us"
            spy={true}
            smooth={true}
            duration={500}
            className="hover:text-brightColor transition-all cursor-pointer"
            onClick={closeMenu}
          >
            About Us
          </Link>
          <Link
            to="/amenities"
            spy={true}
            smooth={true}
            duration={500}
            className="hover:text-brightColor transition-all cursor-pointer"
            onClick={closeMenu}
          >
            Amenities
          </Link>
          <Link
            to="/floor-plan"
            spy={true}
            smooth={true}
            duration={500}
            className="hover:text-brightColor transition-all cursor-pointer"
            onClick={closeMenu}
          >
            Floor Plans
          </Link>
          <Link
            to="/life-style"
            spy={true}
            smooth={true}
            duration={500}
            className="hover:text-brightColor transition-all cursor-pointer"
            onClick={closeMenu}
          >
            Lifestyle
          </Link>
          <Link
            to="/contact"
            spy={true}
            smooth={true}
            duration={500}
            className="hover:text-brightColor transition-all cursor-pointer"
            onClick={closeMenu}
          >
            Contact Us
          </Link>
          <Link
            to="/"
            spy={true}
            smooth={true}
            duration={500}
            className="hover:text-brightColor transition-all cursor-pointer"
            onClick={closeMenu}
          >
            Forms & Rules
          </Link>
          <Link
            to="/"
            spy={true}
            smooth={true}
            duration={500}
            className="hover:text-brightColor transition-all cursor-pointer"
            onClick={closeMenu}
          >
            Residents Only
          </Link>
          <Link
            to="/"
            spy={true}
            smooth={true}
            duration={500}
            className="hover:text-brightColor transition-all cursor-pointer"
            onClick={closeMenu}
          >
            Notices
          </Link>
          <Link
            to="/"
            spy={true}
            smooth={true}
            duration={500}
            className="hover:text-brightColor transition-all cursor-pointer"
            onClick={closeMenu}
          >
            Insurance
          </Link>
        </div>
      </div>
    </div>
  );
};

export default Navbar;


