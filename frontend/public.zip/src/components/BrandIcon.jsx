/* eslint-disable linebreak-style */
/* eslint-disable react/jsx-filename-extension */
/* eslint-disable import/extensions */

import React from 'react';


export default function BrandIcon() {
  return (
    <div
      className=""
      type="link"
      href="/"
    >
      <p className="text-theme-blue text-4xl font-medium ">
        Pinna
        <span className="text-theme-purple">cle</span>
      </p>
    </div>
  );
}